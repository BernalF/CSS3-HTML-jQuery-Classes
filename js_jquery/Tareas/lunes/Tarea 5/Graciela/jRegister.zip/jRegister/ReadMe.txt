﻿**************************************************************************************

Personalmente no tenia idea de como era el mundo javascript, simplemente conocia de
su uso al lado cliente de las aplicaciones web y una que otra funcion super sencilla.
Ahora veo su gran uso y la flexibilidad que me permite al desarrollar aplicaciones.
Estoy muy agradecida con el curso, muchas gracias Bernal, tiene dotes de buen profesor;
no solo por las clases sino porque simpre cuando le consulte sobre algun problema tenia 
la respuesta y extendia su tiempo para explicaciones tecnicas y dar razones del por que 
de la solucion (mejor rendimiento/ practica) , y eso me ayudo mucho a no hacer las cosas 
por hacerlas para que funcionaran sino a cuestionarme e investigar mas.

Una de las cosas que mas me gusto de lo aprendido fue el uso de modulos, lo considero
una solucion limpia y focalizada. Se que por el tiempo no hubo la oportunidad de ver
mas cosas como extender metodos o funciones. Y en general, tengo una mejor nocion de
javascript y jquery aunque se que hay muchas cosas que me faltan entender para poder
tener dominio.


Problemas:
Mas que problemas de javascript o jquery me encontre con problemas de compatiblidad de
HTML entre exploradores. Pero algunos problemillas que si me dieron batalla fue la de
encontrar selectores apropiados al implementar metodos, especialmente con aquellos 
elementos que se insertaban dinamicamente desde el codigo o cuando navegaba dentro de 
algun elemento para obtener ciertos valores, pero nada que el firebug no puediera 
ayudar...realmente una buena herramienta.


Me gustaria conocer de otras librerias o frameworks que implementen funcionalidad
similar a la de jquery, ya que al momento solo he usado esta y seria bueno poder 
experimentar y analizar con otras opciones del mercado.

	

Graciela Paniagua M.
Noviembre 2013.
**************************************************************************************

                                  .' `'.__
                                /      \ `'"-,
               .-''''--...__..-/ .     |      \
             .'               ; :'     '.  a   |
            /                 | :.       \     =\
           ;                   \':.      /  ,-.__;.-;`
          /|     .              '--._   /-.7`._..-;`
         ; |       '                |`-'      \  =|
         |/\        .   -' /     /  ;         |  =/
         (( ;.       ,_  .:|     | /     /\   | =|
          ) / `\     | `""`;     / |    | /   / =/
            | ::|    |      \    \ \    \ `--' =/
           /  '/\    /       )    |/     `-...-`
          /    | |  `\    /-'    /;
          \  ,,/ |    \   D    .'  \
           `""`   \  nnh  D_.-'L__nnh
                   `"""`