Primero que todo no sabia absolutamente nada de jquery excepto que cada selector comenzaba con el simbolo $

Aprendi sobre javascript en donde en una linea de jquery se resume varias lineas de codigo de javascript, poder combinar html, css3 y jquery ha sido muy provechoso para un futuro.

Poder inyectar atributos y eventos a los elementos del html y estilos por medio de jquery.

Aprendi mucho sobre eventos de jquery como FadeIn , FadeOut, closest, siblings, push.

Mi fe es que algun dia pueda obtar por un puesto en front end aunque a veces cueste pero ahi vamos, muchas gracias Bernal Dios lo bendiga por todo el conocimiento que nos ha traspasado y mucha suerte en el nuevo trabajo.
