Esta cosa me esta gustando, me faltan como mil kilometros de camino... pero bueno, ya s� hacer m�s de lo que empece!!!! Es un avance!! 
Me agrado tener que buscar muchas cosas, me falta todav�a implementar mejores practicas, como lo del stopPropagation, pero no lo entiendo bien todav�a, bueno creo que en 
teoria si, pero con eso de pasar el "e" para hacer el preventDefault y eso, me come, voy a ver si lo intento hacer fuera de tarea.

Creo que se hubiera visto mas chiva con algunas librerias adicionales jejejejejeje pero bueno! Aunque no me gane ni un confite, la verdad me sent� feliz conmigo misma!
Quien iba a decir que yo pod�a hacer esto????? Ni yo me lo cre�a... Y soy sincera ni lo iba a entregar... pero lo hice! Yo me siento carga!

No se burle de mis colores, son los del cuarto de princesita Sof�a!
