*******************************************************************************************
*					README					          *
*											  *
*******************************************************************************************
He descubierto que esto del javascript es todo un mundo. Uno nunca sabe que lo que esta 
haciendo cada ves se puede mejorar y se puede simplificar. 
 
Dentro de los problemas principales fueron el como agregar el evento de un boton creado
dinamicamente puesto que el evento "on" se usa para delegar eventos despues de la version 1.7
Que detalle!!!

Luego me tope con problemas de css, en explorer se descuadraron los campos y en Chrome tambien 
tuve que cambiar los porcentajes para que en todo lado luciera igual.
Genius!!!

Pero la Odisea mas grande fue encontrar la mejor manera o al menos que funcionara la validacion
para saber cuando el check estaba en "Yes".

Fue interesante hacer el comportamiendo del edit porque era diferente a la tarea anterior ademas
de que me permitio notar la dinamicidad con respecto al DOM y lo facil que es hacer cambios en el
por medio de jquery.

Tambien pude crear unas imagencitas lo mas bonitas de unos perritos. Quiero un perrito! =3

En general fue todo una aventura, es muy diferente todo lo que se puede hacer con JQuery que 
no se puede hacer con Javascript. 

:)

*******************************************************************************************
*					Fin					          *
*											  *
*******************************************************************************************


